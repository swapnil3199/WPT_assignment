import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { OwnerserviceService } from 'src/app/services/ownerservice.service';

@Component({
  selector: 'app-addowner',
  templateUrl: './addowner.component.html',
  styleUrls: ['./addowner.component.css']
})
export class AddownerComponent {
  reactiveForm!: FormGroup;
  clientId!:number;
  constructor(private owner:OwnerserviceService ,private router:Router ,private fb:FormBuilder){}

  ngOnInit(): void { 
    this.reactiveForm = this.fb.group({
     
      ownerName:[],
      mobile:[],
      email:[],
      address:[],
      city:[],
      state:[],
      pincode:[],
      typeOfHouse:[],
      rentalAmount:[],
    })
  }

  addNewOwner() {
    if (this.reactiveForm.valid) {
      const formdata = this.reactiveForm.value;
      console.log(formdata);
      this.owner.addNewOwner(formdata).subscribe({
        next: (response) => {
         
          console.log(response);
          this.reactiveForm.reset();
        },
        error:(er) => {
          console.log(er);
         
        },
      });
    }
  }
}

