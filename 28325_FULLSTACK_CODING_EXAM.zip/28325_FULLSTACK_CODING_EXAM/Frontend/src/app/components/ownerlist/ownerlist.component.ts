import { Component } from '@angular/core';
import { Owner } from 'src/app/models/owner.model';
import { OwnerserviceService } from 'src/app/services/ownerservice.service';

@Component({
  selector: 'app-ownerlist',
  templateUrl: './ownerlist.component.html',
  styleUrls: ['./ownerlist.component.css']
})
export class OwnerlistComponent {
  owner: Owner[] = [];
  constructor(private ownerservice: OwnerserviceService) {}

  ngOnInit(): void {
    this.ownerservice.getAllOwnerDetails().subscribe({
      next: (response) => {
        this.owner = response;
      },
      error: (err) => {
        console.log(err);
      },
    });

    
  }
}
