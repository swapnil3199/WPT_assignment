export interface Owner{
    ownerId:number;
    ownerName:string;
    mobile:string;
    email:string;
    address:string;
    city:string;
    state:string;
    pincode:string;
    typeOfHouse:string;
    rentalAmount:string;
}