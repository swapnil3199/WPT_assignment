import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OwnerlistComponent } from './components/ownerlist/ownerlist.component';
import { AddownerComponent } from './components/addowner/addowner.component';

const routes: Routes = [
  {path:'ownerlist',component:OwnerlistComponent},
  {path:'addowner',component:AddownerComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
