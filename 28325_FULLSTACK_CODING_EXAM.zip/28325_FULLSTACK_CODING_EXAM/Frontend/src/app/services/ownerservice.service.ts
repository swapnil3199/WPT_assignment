import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Owner } from '../models/owner.model';



@Injectable({
  providedIn: 'root'
})
export class OwnerserviceService {
  constructor(private http: HttpClient) {}

  getAllOwnerDetails(): Observable<Owner[]> {
    return this.http.get<Owner[]>('https://localhost:7080/api/OwnerDetails');
  }

  addNewOwner(addOwnerRequest: Owner): Observable<Owner[]> {
    return this.http.post<Owner[]>(
      'https://localhost:7080/api/OwnerDetails/',
      addOwnerRequest
    );
  }

}
