﻿using System;
using System.Collections.Generic;
using Backend.Models;
using Microsoft.EntityFrameworkCore;

namespace Backend.Dbcontext;

public partial class CodingExamDbContext : DbContext
{
    public CodingExamDbContext()
    {
    }

    public CodingExamDbContext(DbContextOptions<CodingExamDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<OwnerDetail> OwnerDetails { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=CVC226;Initial Catalog=CodingExamDB;Persist Security Info=True; Encrypt=false;User ID=sa;Password=cybage@123456");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<OwnerDetail>(entity =>
        {
            entity.HasKey(e => e.OwnerId).HasName("PK__OwnerDet__819385B8E8B7BB0C");

            entity.Property(e => e.Address).HasMaxLength(500);
            entity.Property(e => e.City).HasMaxLength(40);
            entity.Property(e => e.Email).HasMaxLength(50);
            entity.Property(e => e.Mobile).HasMaxLength(100);
            entity.Property(e => e.OwnerName).HasMaxLength(100);
            entity.Property(e => e.Pincode).HasMaxLength(20);
            entity.Property(e => e.RentalAmount).HasMaxLength(25);
            entity.Property(e => e.State).HasMaxLength(40);
            entity.Property(e => e.TypeOfHouse).HasMaxLength(10);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
