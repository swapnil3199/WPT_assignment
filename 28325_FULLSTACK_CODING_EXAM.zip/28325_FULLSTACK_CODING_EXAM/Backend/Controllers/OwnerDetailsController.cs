﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Backend.Dbcontext;
using Backend.Models;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OwnerDetailsController : ControllerBase
    {
        private readonly CodingExamDbContext _context;

        public OwnerDetailsController(CodingExamDbContext context)
        {
            _context = context;
        }

      
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OwnerDetail>>> FindHouseForMe()
        {
          if (_context.OwnerDetails == null)
          {
              return NotFound();
          }
            return await _context.OwnerDetails.ToListAsync();
        }

       

      
        [HttpPost]
        public async Task<ActionResult<OwnerDetail>> AddMyPropertyForRentalPurpose(OwnerDetail ownerDetail)
        {
          if (_context.OwnerDetails == null)
          {
              return Problem("Entity set 'CodingExamDbContext.OwnerDetails'  is null.");
          }
            _context.OwnerDetails.Add(ownerDetail);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOwnerDetail", new { id = ownerDetail.OwnerId }, ownerDetail);
        }

     
        
        private bool OwnerDetailExists(int id)
        {
            return (_context.OwnerDetails?.Any(e => e.OwnerId == id)).GetValueOrDefault();
        }
    }
}
