﻿using System;
using System.Collections.Generic;

namespace Backend.Models;

public partial class OwnerDetail
{
    public int OwnerId { get; set; }

    public string OwnerName { get; set; } = null!;

    public string Mobile { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Address { get; set; } = null!;

    public string City { get; set; } = null!;

    public string State { get; set; } = null!;

    public string Pincode { get; set; } = null!;

    public string TypeOfHouse { get; set; } = null!;

    public string RentalAmount { get; set; } = null!;
}
